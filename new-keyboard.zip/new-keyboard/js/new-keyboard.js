// Image change on click.
// let key = document.getElementsByClassName('key');
// console.log(key);---worked.

// where i want to display.
// var big_image = document.getElementById('big-image').src;

// key to display.
// var key = document.getElementsByClassName('key');

// from where i want to display img.
// created a pics array.
var imageArray = new Array(["`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "0", "-", '=', "backspace", "tab", "img-alphabet/img_q.jpg", "img-alphabet/img_w.jpg", "img-alphabet/img_e.jpg", "img-alphabet/img_r.jpg", "img-alphabet/img_t.jpg", "img-alphabet/img_y.jpg", "img-alphabet/img_u.jpg", "img-alphabet/img_i.jpg", "img-alphabet/img_o.jpg", "img-alphabet/img_p.jpg", "[", "]", "", "capslock", "img-alphabet/img_a.jpg", "img-alphabet/img_s.jpg", "img-alphabet/img_d.jpg", "img-alphabet/img_f.jpg", "img-alphabet/img_g.jpg", "img-alphabet/img_h.jpg", "img-alphabet/img_j.jpg", "img-alphabet/img_k.jpg", "img-alphabet/img_l.jpg", ";", "'", "Enter", "shift", "img-alphabet/img_z.jpg", "img-alphabet/img_x.jpg", "img-alphabet/img_c.jpg", "img-alphabet/img_v.jpg", "img-alphabet/img_b.jpg", "img-alphabet/img_n.jpg", "img-alphabet/img_m.jpg", ",", ".", "/", "shift", "ctrl", "window", "alt", "spaceBar", "alt", "ctrl", "left", "right", "down", "right"]).src;


var bigimg = document.getElementById("big-image");
var key = document.getElementsByClassName("key");
var i;
// var imageArry = new Array();
for (i = 0; i <= key.length; i++) {
    imageArray[i] = new Array();
    imageArray[i].src = "img-alphabet/" + "img_" + i + ".jpg";
}

/*
imageArry[0]=new Image();
imageArry[0].src='images/b.jpg';
imageArry[1]=new Image();
imageArry[1].src='images/c.jpg';
*/

for (i = 0; i < key.length; i++) {
    key[i].addEventListener("click", daaa.bind(null, i));
    alert("Hello")
    //console.log(smimg[1].src);
}

function daaa(ind) {
    //alert(this.p);
    bigimg.src = imageArray[ind].src;
    //document.getElementById("bigalp").innerHTML=this.innerHTML;
    // bigimg.src=this.src;
}



















// var p;

// var imageArry = new Array();
// for (p = 0; p <= 25; p++) {
//     imageArry[i] = new Image();
//     imageArry[i].src = 'img-alphabet/' + 'img_' + i + '.jpg';
// }


// for (i = 0; i < key.length; i++) {

//     classes[i].addEventListener('click', daaa.bind(null, p));


//     //console.log(smimg[1].src);
// }

// function daaa(ind) {
//     //alert(this.p);
//     bigimg.src = imageArry[ind].src;
//     //document.getElementById("bigalp").innerHTML=this.innerHTML;
//     // bigimg.src=this.src;
// }


// var key = document.getElementsByClassName('key');

// !For...Loop...This is the or loop syntax.
// for (let p = 0; p < key.length; p++) {
//     key[p].addEventListener('click', function () {
//         alert("Hello")
//         // big_image.src = "img-alphabet/" + pics.src;
//         imageArray[p] = new Image();
//         imageArray[p].src = imageArray.src;
//     })

// }